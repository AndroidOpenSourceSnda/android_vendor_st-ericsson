

long
__negsi2(long x)
{
  return ~x+1;
}
