#ifndef _SYS_SCHED_H
#define _SYS_SCHED_H
#ifdef __cplusplus
extern "C" {
#endif

int sched_yield(void);

#ifdef __cplusplus
}
#endif
#endif
